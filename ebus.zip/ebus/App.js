import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';

import Login from './components/Login';
import Cadastrar from './components/Cadastrar';
import Horario from './components/Horario';
import Reservas from './components/Reservas';
import Reservar from './components/Reservar';

const stack=createStackNavigator();
const bottomTab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <bottomTab.Navigator initialRouteName="Login">
        <bottomTab.Screen name="Login" component={Login} options={{tabBarStyle:{display: "none",},}}/>
        <bottomTab.Screen name="Cadastrar" component={Cadastrar} options={{tabBarStyle:{display: "none",},}}/>
        <bottomTab.Screen name="Reservar" component={Reservar}/>
        <bottomTab.Screen name="Reservas" component={Reservas}/>
        <bottomTab.Screen name="Horario" component={Horario}/>
      </bottomTab.Navigator>
    </NavigationContainer>
  );
}