import * as React from 'react';
import { Text, View, StyleSheet, TextInput, ImageBackground, Pressable} from 'react-native';
import Constants from 'expo-constants';

export default function Reservas({navigation}){
 return( 
   <View>
   <Text style={styles.texto}> Reservas para dia 12 de julho</Text>
   <Text style={styles.subtitulo}> Nenhuma reserva cadastrada! </Text>
   </View>
 );
}

const styles = StyleSheet.create({
  texto:{
    fontSize: 16,
    color: 'blue',  
    textAlign: 'center',
    marginTop: 10,
    fontWeight: 'bold'
  },

  subtitulo: {
    textSize: 12,
    textAlign: 'center',
    color: 'red',
    marginTop: 10,
    fontWeight: 'bold'
  }
});