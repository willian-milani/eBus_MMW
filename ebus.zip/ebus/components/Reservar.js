import * as React from 'react';
import { Text, View, StyleSheet, TextInput, ImageBackground, Pressable} from 'react-native';
import { RectButton } from 'react-native-gesture-handler';
import Constants from 'expo-constants';

export default function Reservar({navigation}){
  return(
  <View style={styles.tela}>
   <RectButton style={styles.botao}><Text> De: Leopoldina - Para: Cataguases </Text>
   <Text> Horário: 17:10 - Data: 12/07/2022 </Text> 
   </RectButton>
   </View>
 );
}

const styles = StyleSheet.create({
  botao: {
    height: 40,
    padding: 5,
    backgroundColor: 'white',
    borderRadius: 15,
  },
  tela: {
    backgroundColor: 'white',
    flex: 1,
  },
});
