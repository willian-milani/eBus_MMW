import * as React from 'react';
import { Text, View, StyleSheet, TextInput, ImageBackground, Pressable} from 'react-native';


export default function Horario({navigation}){
 return( 
   <View>
   </View>
 );
 }