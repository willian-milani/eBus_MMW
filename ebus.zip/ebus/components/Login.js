import * as React from 'react';
import { Text, View, StyleSheet, TextInput, ImageBackground, Pressable, Image} from 'react-native';
import { RectButton } from 'react-native-gesture-handler';
import Constants from 'expo-constants';

export default function Login({navigation}){
  return(
   <View style={styles.tela}>
    <ImageBackground source={require("../assets/background_icon.png")} resizeMode="cover" style={styles.tela}>
    <View style={styles.logo}>
    <Image style={{width:200, height:100, margin:10}}source={require('../assets/logoeBus1.png')}/>
    </View>
    <TextInput
        style={styles.input}
        placeholder="E-mail"
      />
      <TextInput
        style={styles.input}
        placeholder="Senha"
      />
   <RectButton style={styles.botao}><Text style={styles.h2}>Entrar</Text> </RectButton>
   <Text style={styles.h1}>Cadastrar-se</Text>
   <Text style={styles.h1}>Esqueceu sua senha?</Text>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    justifyContent: "center",
  },
  h1: {
    color:'white',
    fontWeight: 'bold',
    textAlign: 'center',

  },
   h2: {
    color:'#1B235A',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    height: 40,
    marginTop: 0,
    marginBottom: 15,
    marginLeft: 17,
    marginRight: 17,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#1B235A',
    borderRadius: 15,
  },
  botao: {
    height: 30,
    marginTop: 0,
    marginBottom: 14,
    marginLeft: 75,
    marginRight: 75,
    padding: 5,
    backgroundColor: 'white',
    borderRadius: 15,
  },
  logo: {
    alignItems: "center",
  },
});
