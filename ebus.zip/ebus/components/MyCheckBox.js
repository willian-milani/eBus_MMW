import React from 'react';
import { Text, View, CheckBox, StyleSheet } from "react-native" 

export default function MyCheckBox(props) {
  return (
    <View style={estilos.item}>
   <CheckBox/>
   <Text style={estilos.texto}>{props.texto}</Text>
   </View>
  );
}

const estilos = StyleSheet.create({
  item :{
    flexDirection: "row",
    alignItems: "center",
  },
  texto:{
      margin:5,
  }
})