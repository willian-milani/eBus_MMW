import * as React from 'react';
import {Text,View,TextInput,StyleSheet,ImageBackground,Pressable,SafeAreaView, ScrollView, StatusBar} from 'react-native';
import { RectButton } from 'react-native-gesture-handler';
import MyCheckBox from './MyCheckBox';

export default function Cadastrar({navigation}){
  return (
   <SafeAreaView style={styles.container}>
  <ScrollView style={styles.scrollView}>
    <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Nome"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="E-mail"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Senha"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Confirmar Senha"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="CEFET-MG - Campus Leopoldina"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Matrícula"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Telefone"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="CEP"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Rua"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Número"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Complemento"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Bairro"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="Cidade"
      />
      <TextInput placeholderTextColor="#0000fe"
        style={styles.input}
        placeholder="UF"
      />
      <MyCheckBox texto= 'Concordo com a Política de Privacidade'/>
   <RectButton style={styles.botao}><Text style={styles.h2}>Confirmar</Text> </RectButton>
   <Text style={styles.h1}>Já sou cadastrado</Text>
    </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },
  h1: {
    color:'#2b3683',
    fontWeight: 'bold',
    textAlign: 'center',

  },
   h2: {
    color:'#fbfeff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  input: {
    height: 40,
    marginTop: 0,
    marginBottom: 15,
    marginLeft: 17,
    marginRight: 17,
    borderWidth: 1,
    padding: 10,
    backgroundColor: '#d9d9d9',
    borderRadius: 15,
  },
  botao: {
    height: 30,
    marginTop: 0,
    marginBottom: 14,
    marginLeft: 75,
    marginRight: 75,
    padding: 5,
    backgroundColor: '#283593',
    borderRadius: 15,
  },
  scrollView: {
    backgroundColor: '#f2f2f2',
    marginHorizontal: 20,
  },
});
